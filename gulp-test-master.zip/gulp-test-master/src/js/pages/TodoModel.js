(function(app){

  app.model = {

    id: '',
    title: ''
    

  };
})(Todo);
