// Todo app 전역
var Todo = {
  $wrap: $(document.body),
  storageKey: 'todos'
};

